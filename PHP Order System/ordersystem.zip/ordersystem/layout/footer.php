</div>
</div>
</div>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="js\Datatable.js"></script>
<script type="text/javascript" src="js\DatatableJquery.js"></script>
<script type="text/javascript" src="js\ButtonDatatable.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<script src="js/jquery.js"></script>
<script type="text/javascript">
   $(document).ready(function(){
       $('#btn-print').click(function(){
        var prim = document.getElementById('table');
        var vmw = window.open("","","width=2000,height=700");
        vmw.document.write(prim.outerHTML);
        vmw.document.close();
        vmw.focus();
        vmw.print();
        // vmw.close();
       })


       
   })
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#example').DataTable({
            buttons: [
                'pdf'
            ]
        });
    });
</script>
</body>

</html>