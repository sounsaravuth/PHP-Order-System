<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title><?php echo $title ?></title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="css/styles.css" rel="stylesheet" />
    <link href="css/font/css/font-awesome.css" rel="stylesheet" />
    <link href="css/font/css/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="css\Datatable.css" />
    <link rel="stylesheet" type="text/css" href="css\ButtonDatatable.css" />
	<script type="text/javascript">
		window.history.forward();
	</script>

</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar-->
        <div class="border-end bg-white" id="sidebar-wrapper">
            <div class="sidebar-heading border-bottom  "><b> Order POS</b> </div>
            <div class="list-group list-group-flush">
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="index.php"><i class="fa fa-tachometer" aria-hidden="true"></i> &nbsp; Dashboard</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="Order.php"><i class="fa fa-cart-plus" aria-hidden="true"></i> &nbsp;Order</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="UserCreate.php"><i class="fa fa-user" aria-hidden="true"></i> &nbsp; User Create</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="UserList.php"><i class="fa fa-list" aria-hidden="true"></i> &nbsp; User List</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="ProductCreate.php"> <i class="fa fa-product-hunt" aria-hidden="true"></i> &nbsp; Product Create</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="ProductList.php"><i class="fa fa-list" aria-hidden="true"></i> &nbsp; Product List</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="CategoryCreate.php">Category Create</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="CategoryList.php"><i class="fa fa-list" aria-hidden="true"></i> &nbsp; Category List</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="ReportProduct.php"><i class="fa fa-file" aria-hidden="true"></i> &nbsp; Report Product</a>
                <a class="list-group-item list-group-item-action list-group-item-light p-3" href="#!"><i class="fa fa-cogs" aria-hidden="true"></i> &nbsp; Setting</a>

            </div>
        </div>
        <!-- Page content wrapper-->
        <div id="page-content-wrapper">
            <!-- Top navigation-->
            <div class="container-fluid my-md-3">