<?php session_start(); ?>
<?php include('layout/topbar.php'); ?>
<?php
$title = "Category Create";
include('layout/Header.php'); ?>
<section>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form action="CategoryCode.php" method="POST">
                     
                        <div class="form-row">
                            <label for="Category">Category Name</label>
                            <input type="text" name="categoryname" class="form-control" id="" placeholder="Category Name" required>
                        </div>
                        
                        <div class="my-md-1">
                            <button type="submit" class="btn btn-info" name="addcate">Add New Category</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>