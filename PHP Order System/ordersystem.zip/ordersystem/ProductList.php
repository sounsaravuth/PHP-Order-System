<?php session_start(); ?>
<?php include('layout/topbar.php'); ?>

<?php
$title = "Product List";
include('layout/Header.php');

?>
<section>
    <div class="row">
        <div class="col-md-12">
            <?php
            if (isset($_SESSION['msgpro'])) {
            ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <strong>Record Save</strong> <?php echo $_SESSION['msgpro']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msgpro']);
            }

            ?>
            <?php
            if (isset($_SESSION['msgupdate'])) {
            ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Record Update</strong> <?php echo $_SESSION['msgupdate']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msgupdate']);
            }

            ?>
            <?php
            if (isset($_SESSION['msgdelete'])) {
            ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Record Delete</strong> <?php echo $_SESSION['msgdelete']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msgdelete']);
            }

            ?>
            <?php
            if (isset($_SESSION['msgerror'])) {
            ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Record Error</strong> <?php echo $_SESSION['msgerror']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msgerror']);
            }

            ?>
            <?php
            if (isset($_SESSION['msgimage'])) {
            ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>Image Already Extist</strong> <?php echo $_SESSION['msgimage']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msgimage']);
            }

            ?>
            <div class="card">
                <div class="card-header">
                    <a href="ProductCreate.php" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add More Product</a>
                </div>
                <div class="card-body">
                    <table id="example"  class="table table-hover">
                        <thead class="text text-center">
                            <tr>
                                <th scope="col">Image Product</th>
                                <th scope="col">Product Name</th>
                                <th scope="col">price</th>
                                <th scope="col">Category Name</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php
                            $con = mysqli_connect("localhost", "root", "", "ordersys"); #connection PHP To Database LocalConnection
                            $querys = "SELECT * FROM tblproduct";

                            $querys = "SELECT * FROM tblcategory inner join tblproduct on tblproduct.category_id = tblcategory.id";
                            // $querys = "SELECT * FROM tblcategory inner Join tblproduct on tblcategory.id = tblproduct.id ";
                            $msql = mysqli_query($con, $querys);
                            if (mysqli_num_rows($msql) > 0) {
                                foreach ($msql as $row) {
                            ?>
                                    <tr>                                 
                                        <td>
                                            <img src="<?php echo "upload/" . $row['image']; ?>" width="50px" class="rounded-pill" alt="logo">
                                        </td>
                                        <td><?= $row['productname']; ?></td>
                                        <td><?= number_format( $row['price'],2); ?></td>
                                       
                                            <td><?= $row['categoryname']; ?></td>
                                        <td>
                                            <form action="ProductEdit.php?id=<?= $row['id']; ?>" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                                                <button type="submit" class="btn btn-success"><i class="fa fa-edit" aria-hidden="true"></i> Edit Record</button>
                                            </form>
                                        </td>
                                        <td>
                                            <form action="ProductCode.php?id=<?=$row['id']?>" method="POST" enctype="multipart/form-data">
                                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                                <button type="submit" class="btn btn-danger" name="delete"><i class="fa fa-trash" aria-hidden="true"></i> Delete Record</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php

                                }
                            } else {
                                ?>
                                <h1>No Record Product</h1>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>