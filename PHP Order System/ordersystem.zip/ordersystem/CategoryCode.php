<?php
session_start();
#connection PHP To Database LocalConnection
$con = mysqli_connect("localhost", "root", "", "ordersys");
if (isset($_POST['addcate'])) {
    // $id = $_POST['id'];
    $catename = $_POST['categoryname'];
    
    $query_sql = "insert into tblcategory(categoryname) values('$catename')";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
        $_SESSION['msg'] = "Category Record Save Successfully";
        header("Location: CategoryList.php");
    } else {
        $_SESSION['msg'] = "Data Not Inserted";
        header("Location: CategoryCreate.php");
    }
}


//Update Data
if (isset($_POST['upcate'])) {

    $id = $_POST['id'];
    $catename = $_POST['categoryname'];
    $query_sql = "UPDATE tblcategory SET categoryname='$catename' WHERE id='$id' ";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
        $_SESSION['msgupdate'] = "Category Record Update Successfully";
        header("Location: CategoryList.php");
    } else {
        $_SESSION['msgupdate'] = "Data Not Inserted";
        header("Location: CategoryCreate.php");
    }
}

//Delete Record
if (isset($_POST['adddelete'])) {

    $id = $_POST['id'];
    $query_sql = " DELETE FROM tblcategory WHERE id='$id' ";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
        $_SESSION['msgdelete'] = "Category Record Delete Successfully";
        header("Location: CategoryList.php");
    } else {
        $_SESSION['msgdelete'] = "Data Not Inserted";
        header("Location: CategoryCreate.php");
    }
}
