<?php session_start(); ?>
<?php include('layout/topbar.php'); ?>
<?php
$title = "Order Drink";
include('layout/Header.php'); ?>


<?php
  $con = mysqli_connect("localhost", "root", "", "ordersys"); #connection PHP To Database LocalConnection
  if(isset($_POST['orderfood']))
 {
     if(isset($_SESSION['cart']))
     {
        $session_array_id = array_column($_SESSION['cart'],"id");
if (!in_array($_GET['id'], $session_array_id)) {
 $session_array = array(
             'id'=>$_GET['id'],
              'productname'=>$_POST['productname'],
              'price'=>$_POST['price'],
              'qty'=>$_POST['qty'],
         );
         $_SESSION['cart'][]= $session_array;

        }
     }  else
     {
         $session_array = array(
             'id'=>$_GET['id'],
              'productname'=>$_POST['productname'],
              'price'=>$_POST['price'],
               'qty'=>$_POST['qty'],
         );
         $_SESSION['cart'][]= $session_array;
     }
 }
?>
<section>
     <div class="row">
       <div class="col-md-7">
           <div class="row  ">
    <?php
           $con = mysqli_connect("localhost", "root", "", "ordersys"); #connection PHP To Database LocalConnection
            $querys = "SELECT * FROM tblcategory inner join tblproduct on tblproduct.category_id = tblcategory.id";
             $msql = mysqli_query($con, $querys); 
            if(mysqli_num_rows($msql) > 0)
            foreach ($msql as $key) {
                ?>                    
                    <div class="col-md-3 ">
                           <form method="post" action="Order.php?id=<?=$key['id']?>" >  
                <div class="card ">               
                      <img src="<?php echo "upload/" . $key['image']; ?>" width="50px" class="card-img-top" alt="logo">
                    <div class="card-body">
                        <h4 class="card-title text text-center"> <?=$key['productname']?></h4>
                    </div>
                    <ul class="list-group list-group-flush">
                          <li class="list-group-item">Product&nbsp;&nbsp; <?=$key['productname']?></li>
                          <li class="list-group-item">category: &nbsp;&nbsp; <?=$key['categoryname']?></li>
                           <li class="list-group-item">Price: &nbsp;&nbsp; <?= number_format( $key['price'],2)?></li>
                           <input type="hidden" name="productname" value="<?=$key['productname'];?>">
                             <input type="hidden" name="categoryname" value="<?=$key['categoryname'];?>">
                               <input type="hidden" name="price" value="<?=$key['price'];?>">
                                 <input type="hidden" name="qty" value="<?=$key['qty'];?>">
                        <li class="list-group-item">
                            <input type="number" name="qty" value="1" class="form-control" id="" placeholder="Qty">
                        </li>
                        <li class="list-group-item ">
                           &nbsp;   &nbsp; <button type="submit"  class="btn btn-info " name="orderfood"><i class="fa fa-cart-plus" aria-hidden="true"></i> Order Food</button>
                        </li>
                    </ul>
                </div>
                 </form>
               </div>                
                <?php
            }   else{     
            ?>
                <h1>No Reocrd Product</h1>
            <?php
            }
    ?>                       
           </div>
       </div>
        <div class="col-md-5">
            <div class="card">
                <div class="card-header" >
                    <img src="https://cdn-icons.flaticon.com/png/512/685/premium/685301.png?token=exp=1648602501~hmac=77e9687046a6a1314e36210908f803aa" width="100px" alt="Logo Invice" style="margin-left: auto; margin-right: auto;">
                    <span style="margin-left: 150px; font-weight: bold; font-size: 30px;letter-spacing: 2px;">Invoice Order 24</span>
                </div>
                <div class="card-body ">
                    <table  class="table table-hover fixed" id="table">
                        <thead>
                            <tr>                           
                                 <th>Product Name</th>                        
                                <th>Price</th>
                                <th>Qty</th>
                                <th>Total</th>
                                <th>Action</th>                             
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                            $output = "";
                            if(!empty($_SESSION['cart'])){
                                    foreach ($_SESSION['cart'] as $key =>$value) {
                                  $output .="
                                    <tr>
                                   <td>".$value['productname']."</td>
                                     <td> $".number_format($value['price']) ."</td>
                                     <td> ". $value['qty'] ."</td>
                                     <td>$".number_format( $value['qty']* $value['price'])."</td>
                                    <td>
                                    <a  href='Order.php?action=remove&id=".$value['id']."'>
                                        <button class='btn btn-danger' >Remove</button>
                                    </a>
                                    </td>
                                    </tr>
                                  ";
                                  $total = $total+$value['price']*$value['qty'];
                                }
                             $output.="
                             
                             <tr>
                             <td colspan='2'></td>
                             <td>Total</td>
                             <td>$".number_format($total,2)."</td>
                             <td></td>
                             </tr>
                             ";
                            }
                            
                         echo $output;
                              
                            
                            ?>
                        </tbody>
                            
                    </table>
                    <?php
                   if(isset($_GET['action'])){
                       if($_GET['action'] == "remove")
                       {
                             foreach ($_SESSION['cart'] as $key => $value) {
                             if($value['id'] == $_GET['id']){
                                unset($_SESSION['cart'][$key]);
                             }
                            
                           }
                       }
                   }                    
                    ?>
                </div>
                <div class="card-footer">
                    <button id="btn-print" class="btn btn-success" >Print Invoice</button>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>