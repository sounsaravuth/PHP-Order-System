<?php session_start(); ?>
<?php include('layout/topbar.php'); ?>

<?php
$title = "Product List";
include('layout/Header.php');
?>
<section>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <button id="btn-print" class="btn btn-success">Print Report</button>
                </div>
                <div class="card-body">
                    <table id="example"  class="table table-hover">
                        <thead class="text text-center">
                            <tr>
                                <th scope="col">Image Product</th>
                                <th scope="col">Product Name</th>
                                <th scope="col">price</th>
                                <th scope="col">Category Name</th>

                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php
                            $con = mysqli_connect("localhost", "root", "", "ordersys"); #connection PHP To Database LocalConnection
                            $querys = "SELECT * FROM tblproduct";
                            $querys = "SELECT * FROM tblcategory inner join tblproduct on tblproduct.category_id = tblcategory.id";
                          
                            $msql = mysqli_query($con, $querys);
                            if (mysqli_num_rows($msql) > 0) {
                                foreach ($msql as $row) {
                            ?>
                                    <tr>                                 
                                        <td>
                                            <img src="<?php echo "upload/" . $row['image']; ?>" width="50px" class="rounded-pill" alt="logo">
                                        </td>
                                        <td><?= $row['productname']; ?></td>
                                        <td><?= number_format( $row['price'],2); ?></td>
                                       
                                            <td><?= $row['categoryname']; ?></td>
                                    
                                    </tr>
                                <?php

                                }
                            } else {
                                ?>
                                <h1>No Record Product</h1>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>