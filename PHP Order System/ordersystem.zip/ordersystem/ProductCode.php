<?php
session_start();
#connection PHP To Database LocalConnection
$con = mysqli_connect("localhost", "root", "", "ordersys");
//add Product
if (isset($_POST['addpro'])) {
 
    $proname = $_POST['productname'];
  
    $price = $_POST['price'];
    $categoryid = $_POST['category_id'];
   
    $image = $_FILES['image']['name'];
     $qty = $_POST['qty'];
    $query_sql = "insert into tblproduct (productname,price,category_id,image,qty) values('$proname','$price','$categoryid','$image','$qty')";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
          move_uploaded_file($_FILES['image']['tmp_name'], "upload/" . $_FILES['image']['name']);
        $_SESSION['msgpro'] = "Product Add SuccessFully";
        header("Location:ProductList.php");
        echo "Record Save";
    } else {
        $_SESSION['msgerro'] = "Product Error ";
        header("Location:ProductList.php");
    }
}

if (isset($_POST['updatepro'])) {
    $id = $_POST['id'];
    $proname = $_POST['productname'];
    $detail = $_POST['detail'];
    $categoryid = $_POST['categoryid'];
    $image = $_FILES['image']['name'];
    $oldimage = $_POST['oldimagepro'];
    if ($oldimage != '') {
        $updateImageProduct = $_FILES['imagepro']['name'];
    } else {
        $updateoldimage = $_POST['oldimagepro'];
    }
    if (file_exists("upload/" . $_FILES['imagepro']['name'])) {
        $filename = $_FILES['imagepro']['name'];
        $_SESSION['msgimage'] = "Image Already Extist" . $filename;
        header("Location:ProductList.php");
    } else {
        $query_sql = "update tblproduct set productname='$productname',detail='$detail',categoryid='$categoryid',image='$updateImageProduct' where id='$id'";
        $query_run = mysqli_query($con, $query_sql);
        if ($query_run) {

            if ($_FILES['imagepro']['name'] != '') {
                move_uploaded_file($_FILES['imagepro']['tmp_name'], "upload/" . $_FILES['imagepro']['name']);
                unlink("upload/" . $oldimage);
            }

            $_SESSION['msgupdate'] = "Product Update SuccessFully";
            header("Location:ProductList.php");
        } else {
            echo "Record Unsave";
        }
    }
}

//delete
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $query_sql = "delete from tblproduct where id='$id'";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
        $_SESSION['msgdelete'] = "Product Delete SuccessFully";
        header("Location:ProductList.php");
    } else {
        $_SESSION['msgerror'] = "Product Delete UnsuccessFully";
        header("Location:ProductList.php");
    }
}
