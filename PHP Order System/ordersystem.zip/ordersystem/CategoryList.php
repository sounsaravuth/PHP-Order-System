<?php session_start(); ?>
<?php include('layout/topbar.php'); ?>



<?php
$title = "Category List";
include('layout/Header.php');

?>
<section>
    <div class="row">
        <div class="col-md-12">
            <?php
            if (isset($_SESSION['msg'])) {
            ?>
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <strong>Record Save</strong> <?php echo $_SESSION['msg']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msg']);
            }

            ?>
            <?php
            if (isset($_SESSION['msgupdate'])) {
            ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Record Update</strong> <?php echo $_SESSION['msgupdate']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msgupdate']);
            }

            ?>
            <?php
            if (isset($_SESSION['msgdelete'])) {
            ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Record Delete</strong> <?php echo $_SESSION['msgdelete']; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php
                unset($_SESSION['msgdelete']);
            }

            ?>
            <div class="card">
                <div class="card-header">
                    <a href="CategoryCreate.php" class="btn btn-success"> <i class="fa fa-plus" aria-hidden="true"></i> Add More Category</a>
                </div>
                <div class="card-body">
                    <table id="example" class="table table-hover ">
                        <thead class="text text-center">
                            <tr>
                              
                                <th scope="col">Category Name</th>
                               
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody class="text text-center">
                            <?php
                            $con = mysqli_connect("localhost", "root", "", "ordersys"); #connection PHP To Database LocalConnection
                            $querys = "SELECT * FROM tblcategory";
                            $msql = mysqli_query($con, $querys);
                            if (mysqli_num_rows($msql) > 0) {

                                foreach ($msql as $row) {
                            ?>
                                    <tr>
                                      
                                        <td><?= $row['categoryname']; ?></td>
                                        
                                        <td>
                                            <form action="CategoryEdit.php" method="POST">
                                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                                <button type="submit" class="btn btn-success" name="addup"> <i class="fa fa-edit" aria-hidden="true"></i> Edit Record</button>

                                            </form>
                                        </td>

                                        <td>
                                            <form action="CategoryCode.php" method="POST">
                                                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                                <button type="submit" class="btn btn-danger" name="adddelete"> <i class="fa fa-trash" aria-hidden="true"></i> Delete Record</button>
                                            </form>
                                        </td>

                                    </tr>
                            <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>