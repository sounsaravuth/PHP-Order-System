<?php include('layout/topbar.php'); ?>
<?php
$title = "Product Edit";
include('layout/Header.php'); ?>
<section>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <?php
                    $con = mysqli_connect("localhost", "root", "", "ordersys");
                    $id = $_POST['id'];
                    $query_sql = "select * from tblproduct where id='$id'";
                    $query_run = mysqli_query($con, $query_sql);
                    $row = mysqli_fetch_assoc($query_run);
                    ?>
                    <form action="ProductCode.php" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $row['id']; ?>">                                             
                        <div class="form-group">
                            <label for="id">Product Name</label>
                            <input type="text" name="productname" class="form-control" value="<?= $row['productname']; ?>">
                        </div>
                        <div class="form-group">
                            <label for="">Price</label>
                           <input type="text" name="price" class="form-control" value="<?=$row['price']?>">
                        </div>
                        <?php
                        $con = mysqli_connect("localhost", "root", "", "ordersys");
                        $querys = "SELECT * FROM tblcategory";
                        $msql = mysqli_query($con, $querys);
                        ?>
                        <div class="form-group">
                            <label for="categoryid">Category Name</label>
                            <select name="categoryid" class="form-control">
                                <option>Select Category Name</option>
                                <?php foreach ($msql as $rows) : ?>
                                    <option value="<?php echo $rows['category_id']; ?>" <?php if ($row['category_id'] == $rows['category_id']) echo 'selected="selected"'; ?>><?php echo $rows['categoryname']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Product Image</label>
                            <input class="form-control" type="file" name="image">
                            <input type="hidden" name="oldimapro" value="<?php echo $row['image']; ?>">
                        </div>
                        <div class="row my-md-2">
                            <div class="form-group">
                                <img src="<?php echo "upload/" . $row['image']; ?>" class="img-thumbnail" width="200px" alt="image-Product">
                            </div>
                        </div>
                        <div class="my-md-2">
                            <button type="submit" class="btn btn-info" name="updatepro">Update Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include('layout/footer.php') ?>