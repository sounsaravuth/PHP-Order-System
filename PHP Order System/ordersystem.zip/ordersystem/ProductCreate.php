
<?php include('layout/topbar.php'); ?>
<?php
$title = "Product Create";
include('layout/Header.php'); ?>
<section>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form action="ProductCode.php" method="POST" enctype="multipart/form-data">                   
                        <div class="form-group">
                            <label for="id">Product Name</label>
                            <input type="text" name="productname" class="form-control" id="">
                        </div>
                          <div class="form-group">
                            <label for="id">Price</label>
                            <input type="text" name="price" class="form-control" id="">
                        </div>
                        <div class="form-group">
                            <label for="id">Qty</label>
                            <input type="number" name="qty" class="form-control" id="">
                        </div>
                        <?php
                        $con = mysqli_connect("localhost", "root", "", "ordersys");
                        $querys = "SELECT * FROM tblcategory";
                        $msql = mysqli_query($con, $querys);
                        ?>
                        <div class="form-group">
                            <label for="categoryid">Category Name</label>
                            <select name="category_id" class="form-control">
                                <option> Select Category Name</option>
                                <?php
                                foreach ($msql as $key) {
                                ?>
                                    <option value="<?= $key['id']; ?>"><?= $key['categoryname'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Product Image</label>
                            <input class="form-control" type="file" name="image">
                        </div>
                        <div class="my-md-1">
                            <button type="submit" class="btn btn-info" name="addpro">Add New Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include('layout/footer.php') ?>