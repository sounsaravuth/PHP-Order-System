
<?php session_start()?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="author" content="Muhamad Nauval Azhar">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="This is a login page template based on Bootstrap 5">
	<title>Login</title>
    <style>
        .btn-login{
            width: 100%;
        }
        label{
            font-weight: bold;
        }
		h1{
			color: blue;
			text-decoration: underline;
			letter-spacing: 2px;
		}
    </style>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	<script type="text/javascript">
		window.history.forward();
	</script>
</head>

<body>
	<section class="h-100">
		<div class="container h-100">
			<div class="row justify-content-sm-center h-100">
				<div class="col-xxl-4 col-xl-5 col-lg-5 col-md-7 col-sm-9">
					<div class="text-center my-5">
						<img src="https://cdn-icons.flaticon.com/png/512/5867/premium/5867414.png?token=exp=1648544019~hmac=13f80d24e6f2eaf0e755ff464d2912e3" alt="logo" width="100">
					</div>
					<div class="card shadow-lg">
						<div class="card-body p-5">
							<h1 class="fs-4 card-title fw-bold mb-4 text-center">FOOD 24 ORDER</h1>
							<form method="POST" action="LoginCode.php" class="needs-validation" novalidate="" autocomplete="off">
								<div class="mb-3">
									<label for="username">UserName</label>
									 <input type="text" name="username" class="form-control" placeholder="UserName" required>
								</div>

								<div class="mb-3">
                                    <label for="password">Password</label>
									  <input type="password" name="password" class="form-control" placeholder="Password" required>
								</div>

								<div class="d-flex align-items-center">
								
									<button type="submit" class="btn btn-primary ms-auto btn-login" name="login">
									Login
									</button>
								</div>
							</form>
						</div>
						
					</div>
					
				</div>
			</div>
		</div>
	</section>

	<script src="js/login.js"></script>
</body>
</html>
