
<?php include('layout/topbar.php'); ?>
<?php
$title = "User Create";
include('layout/Header.php'); ?>

<section>
    <div class="row">
        <div class="col-md-12">
            <div class="card">

                <div class="card-body">
                    <form action="UserCode.php" method="POST">
                       
                        <div class="form-row">
                            <label for="Category"> Name</label>
                            <input type="text" name="name" class="form-control" id="" placeholder="FullName" required>
                        </div>
                        <div class="form-row">
                            <label for="Category"> Gender</label>
                            <select class="form-control" name="gender" required>
                                <option>Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                      
                        <div class="form-row">
                            <label for="dob">Tel</label>
                            <input type="text" name="tel" class="form-control" id="" placeholder="Tel" required>
                        </div>
                            <div class="form-row">
                            <label for="dob">UserName</label>
                            <input type="text" name="username" class="form-control" id="" placeholder="UserName" required>
                        </div>
                           <div class="form-row">
                            <label for="dob">Password</label>
                            <input type="text" name="password" class="form-control" id="" placeholder="Password" required>
                        </div>
                        <div class="my-md-1">
                            <button type="submit" class="btn btn-info" name="adduser"><i class="fa fa-user-circle" aria-hidden="true"></i> Add New User</button>
                            <button type="reset" class="btn btn-secondary">  Clear</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>