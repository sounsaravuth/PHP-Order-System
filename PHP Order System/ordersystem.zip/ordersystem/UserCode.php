<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "ordersys");
//add user
if (isset($_POST['adduser'])) {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $tel = $_POST['tel'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query_sql = "insert into tbluser(name,gender,tel,username,password) values('$name','$gender','$tel','$username','$password')";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
        $_SESSION['msg'] = "User Create Successfully";
        header("Location: UserList.php");
    } else {

        header("Location: UserCreate.php");
    }
}

//update user

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $tel = $_POST['tel'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query_sql = "update tbluser set name='$name',gender='$gender',tel='$tel',username='$username',password='$password' where id='$id' ";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
        $_SESSION['msgupdate'] = "User Update Successfully";
        header("Location: UserList.php");
    } else {
        $_SESSION['msgupdate'] = "User Update Unsuccessfully";
        header("Location: UserList.php");
    }
}


//Delete Record


if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $query_sql = "delete from tbluser where id='$id'";
    $query_run = mysqli_query($con, $query_sql);
    if ($query_run) {
        $_SESSION['msgdelete'] = "User Delete Successfully";
        header("Location: UserList.php");
    } else {
        $_SESSION['msgdelete'] = "User Delete Unsuccessfully";
        header("Location: UserList.php");
    }
}
