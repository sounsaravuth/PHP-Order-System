<?php

#connection PHP To Database LocalConnection
$con = mysqli_connect("localhost", "root", "", "ordersys");

if(isset($_POST['login'])){
 $username = $_POST['username'];
$password = $_POST['password'];
$query_sql = "Select * from tbluser where username='".$username."' and password='".$password."' limit 1";
$query_run = mysqli_query($con,$query_sql);
if(mysqli_num_rows($query_run) == 1){
      $_SESSION['username']=$username;
       header("Location:Order.php");
       
}
else
{
     header("Location:Login.php");
}
}

?>