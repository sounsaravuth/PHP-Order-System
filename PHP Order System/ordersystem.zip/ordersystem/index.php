<?php include('layout/topbar.php'); ?>
<?php
$title = "Admin|Dashboard";
include('layout/Header.php'); ?>
<section>

<!-----PHP Count Data-------->
<?php
#connection PHP To Database LocalConnection
$con = mysqli_connect("localhost", "root", "", "ordersys");
$query_sql = "select id from tblproduct order by id";
$query_run = mysqli_query($con,$query_sql);
$row = mysqli_num_rows($query_run);
?>
<?php
#connection PHP To Database LocalConnection
$con = mysqli_connect("localhost", "root", "", "ordersys");
$query_sql = "select id from tblcategory order by id";
$query_run = mysqli_query($con,$query_sql);
$rows = mysqli_num_rows($query_run);
?>
<?php
#connection PHP To Database LocalConnection
$con = mysqli_connect("localhost", "root", "", "ordersys");
$query_sql = "select id from tbluser order by id";
$query_run = mysqli_query($con,$query_sql);
$rowes = mysqli_num_rows($query_run);
?>
<!------------->
    <div class="row  ">
        <div class="col-md-4 ">
            <div class="card shadow-sm ">           
                <div class="card-body" >
                  <img src="image/box.png" class="img-fluid" alt="background" style="margin-left: 40%;margin-right: 40%;">
                    <div class="card-text">
                        <p class="text text-center">Total Product <b><?php echo $row?></b></p>
                    </div>
                </div>
            </div>
        </div>
         <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <img src="image/man.png" class="img-fluid" alt="background" style="margin-left: 40%;margin-right: 40%;">
                     <div class="card-text">
                        <p class="text text-center">Total User <b><?php echo$rowes?></b></p>
                    </div>
                </div>
            </div>
        </div>
         <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-body">
                    <img src="image/options.png" class="img-fluid" alt="background" style="margin-left: 40%;margin-right: 40%;">
                     <div class="card-text">
                        <p class="text text-center">Total Cateogry <b><?php echo $rows?></b></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
   </section>

<?php include('layout/footer.php') ?>