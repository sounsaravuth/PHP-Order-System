<?php session_start(); ?>
<?php include('layout/topbar.php'); ?>
<?php
$title = "User Edit";
include('layout/Header.php'); ?>
<section>
    <div class="row">
        <!----Fetch Data To Edit----------->
        <?php
        $con = mysqli_connect("localhost", "root", "", "ordersys");  #connection PHP To Database LocalConnection
        $id = $_POST['id'];
        $querys = "SELECT * FROM tbluser where id='$id'";
        $msql = mysqli_query($con, $querys);
        $row = mysqli_fetch_assoc($msql);
        ?>
        <!--------------------------->
        <div class="col-md-12">
            <div class="card">
                <div class=" card-header">
                    <a href="UserList.php" class="float-end btn btn-info">Back </a>
                </div>
                <div class="card-body">
                    <form action="UserCode.php" method="POST">
                            <input type="hidden" name="id" value="<?php echo $row['id']?>">
                        <div class="form-row">
                            <label for="Category"> Name</label>
                            <input type="text" name="name" class="form-control" id="" placeholder="User Name" value="<?= $row['name']; ?>">
                        </div>
                        <div class="form-row">
                            <label for="Category"> Gender</label>
                            <select class="form-control" name="gender">
                                <option>Select Gender</option>
                                <option value="Male" <?php if($row['gender'] == 'Male') { echo 'Selected';}?>>Male</option>
                                <option value="Female" <?php if($row['gender']== 'Female'){echo 'Selected';}?>>Female</option>
                            </select>
                        </div>
                          <div class="form-row">
                            <label for="dob">Tel</label>
                            <input type="text" name="tel" class="form-control" id="" placeholder="UserName" value="<?=$row['tel'];?>" required>
                        </div>
                         <div class="form-row">
                            <label for="dob">UserName</label>
                            <input type="text" name="username" class="form-control" id="" placeholder="UserName" value="<?=$row['username'];?>" required>
                        </div>
                           <div class="form-row">
                            <label for="dob">Password</label>
                            <input type="text" name="password" class="form-control" id="" placeholder="Password" value="<?=$row['password'];?>" required>
                        </div>
                      

                        <div class="my-md-1">
                            <button type="submit" class="btn btn-info" name="update">Update User</button>
                            <button type="reset" class="btn btn-secondary">Clear</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>