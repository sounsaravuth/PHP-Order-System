<?php session_start(); ?>
<?php include('layout/topbar.php'); ?>
<?php
$title = "Category Edit";
include('layout/Header.php'); ?>
<section>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <!----Fetch Record To Edit----->
                    <?php
                    $con = mysqli_connect("localhost", "root", "", "ordersys");  #connection PHP To Database LocalConnection
                    $id = $_POST['id'];
                    $querys = "SELECT * FROM tblcategory where id='$id'";
                    $msql = mysqli_query($con, $querys);
                    $row = mysqli_fetch_assoc($msql);

                    ?>
                    <form action="CategoryCode.php" method="POST">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <div class="form-row">
                            <label for="Category">Category ID</label>
                            <input type="text" name="id" disabled class="form-control" id="" placeholder="Category ID" value="<?= $row['id']; ?>">
                        </div>
                        <div class="form-row">
                            <label for="Category">Category Name</label>
                            <input type="text" name="categoryname" class="form-control" id="" placeholder="Category Name" value="<?= $row['categoryname']; ?>">
                        </div>
                        <div class="my-md-1">
                            <button type="submit" class="btn btn-info" name="upcate">Update Category Product</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include('layout/footer.php') ?>